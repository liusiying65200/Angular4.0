<!DOCTYPE html>
<html>
<head>
    <title>403 Forbidden</title>
</head>
<body>

<p><?php echo $a;?></p>

</body>
</html>
