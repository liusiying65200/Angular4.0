<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//配置自动加载文件

$autoload['packages'] = array();

$autoload['libraries'] = array();

$autoload['drivers'] = array();


$autoload['helper'] = array();


$autoload['config'] = array();


$autoload['language'] = array();


$autoload['model'] = array();
